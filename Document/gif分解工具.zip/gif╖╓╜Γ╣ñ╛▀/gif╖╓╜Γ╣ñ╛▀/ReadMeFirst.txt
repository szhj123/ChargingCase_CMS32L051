=========================================================================
   GifSplitter - Break GIF animation down into individual image frames
=========================================================================
Overview
GifSplitter can break GIF animation down into individual image frames. Then, you can select any frames of the gif animation, and modify them as you like.

Also, GifSplitter will create a .gsf file which can be used in Magic ASCII Studio (http://www.xoyosoft.com/mas). So, with the help of GifSplitter you can make ASCII Art Animation directly from gif animation file in Magic ASCII Studio now. :-)

----
How to use
1.Extract the files of this package to any folder you like. (The addin folder of Magic ASCII Studio is recommended.)
2.Select a gif animation file, and set the output information of the software
3.Use 'Split Now' to break GIF animation down into individual image frames

----
Histories of GifSplitter
Version 2.0:
	1)Add a new feature for users to choose whether to use a single color as the frames background color or not when the GIF uses transparencies
	2)Some bugs have been fixed
	3)The core has been improved
	
	Merry Christmas And Happy New To Everybody! :-)

Version 1.0:
	The first release of GifSplitter.

----
Support Information
e-mail: support@xoyosoft.com
website: http://www.xoyosoft.com/gs

-------------------------------------------------------------------------
Copyright(C)2004-2008 XoYo Software. All Rights Reserved.